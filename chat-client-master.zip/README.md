this app can be run with only compile
this app use for create a new room,enter or leave room,retrieve list of rooms and messages to entered room
===========
`HELP` Displays list of commands
`CREATE <room>` Creates a room with given name
`ENTER <room>` Enters room with given name
`LEAVE <room>` Leaves room with given name
`LIST` Returns list of rooms on the server
`SEND <room> <message>` Sends message to the given room
`BYE` Disconnects from the server
